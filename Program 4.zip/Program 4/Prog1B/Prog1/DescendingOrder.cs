﻿// Program 4
// CIS 200-01
// Due: 4/17/2019
// Grading ID: L3962

// This file sorts items by Copyright year (descending order) utilizng the IComparer Interface.
//and display the newly ordered list.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LibraryItems
{
    public class DescendingOrder : Comparer<LibraryItem>
    {
        //Precondition: None
        //Postcondition: Reverse the order of Copyright Year so it's descending
        public override int Compare(LibraryItem libraryItem1, LibraryItem libraryItem2)
        {
            if (libraryItem1 == null && libraryItem2 == null) // when Both null?
                return 0; // both items Equal

            if (libraryItem1 == null) //only libraryItem1 is null?
                return -1; //null is less than Copyright Year (or any existing object)

            if (libraryItem2 == null) //only libraryItem2 is null?
                return 1; //Copright Year is greater than null

            // descending by copyright order
            return (-1) * libraryItem1.CopyrightYear.CompareTo(libraryItem2.CopyrightYear); 

        }

    }
}
