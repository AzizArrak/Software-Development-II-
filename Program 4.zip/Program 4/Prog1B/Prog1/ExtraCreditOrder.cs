﻿// Program 4
// CIS 200-01
// Due: 4/17/2019
// Grading ID: L3962
// This file sorts items by Type and then by Title (ascending order) within each grouping. utilizng the IComparer Interface. 

using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LibraryItems
{
    public class ExtraCreditOrder : Comparer<LibraryItem>
    {
        public override int Compare(LibraryItem libraryItem1, LibraryItem libraryItem2)
        {
            if (libraryItem1 == null && libraryItem2 == null) //Both null?
                return 0; //when both Equal

            if (libraryItem1 == null) //only libraryItem1 is null?
                return -1; //null is less than Copyright Year

            if (libraryItem2 == null) //only libraryItem2 is null?
                return 1; //Copright Year is greater than null

            int typeCompare = string.Compare(libraryItem1.GetType().ToString(), libraryItem2.GetType().ToString()); // get the type 

            if (typeCompare != 0) // not equal
                return typeCompare;
            else
            {
                    return libraryItem1.Title.CompareTo(libraryItem2.Title); 
            }
        }
    }
}
