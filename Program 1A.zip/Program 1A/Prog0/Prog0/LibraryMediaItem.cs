﻿// Program 1A
// CIS 200-01
// Grading ID L3962
// Due: 02/13/2019
// Description: Abstract class LibraryMediaItem extended from abstract base class LibraryItem

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;



    public abstract class LibraryMediaItem : LibraryItem
    {
        // instance variables
        private double duration;

        // parameter constructor
        public LibraryMediaItem(string theTitle, string thePublisher, int theCopyrightYear, string theCallNumber, 
            int theLoanPeriod, double theDuration) : base(theTitle, thePublisher, theCopyrightYear, theLoanPeriod, theCallNumber)
        {
            // validate via property
            Duration = theDuration;
        }
        // enum for Media Type
        public enum MediaType
        {
            DVD, BLURAY, VHS, CD, SACD, VINYL
        };

        public double Duration
        {
            // Precondition:  None
            // Postcondition: The Duration has been returned
            get
            {
                return duration;
            }

            // Precondition:  value > 0
            // Postcondition: The duration has been set to the specified value
            set
            {
                if (value > 0)
                    duration = value;
                else
                    throw new ArgumentOutOfRangeException($"{nameof(Duration)}", value,
                        $"{nameof(Duration)} Must be >= 0");
            }
        }

        // abstract property for Medium 
        public abstract MediaType Medium { get; set; }


        // Precondition:  None
        // Postcondition: A string is returned presenting the Library Media Item data on
        //                separate lines
        public override string ToString()
        {
            return $"{base.ToString()}Duration: {Duration}";
        }
    }

