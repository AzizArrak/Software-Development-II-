﻿// Program 1A
// CIS 200-01
// Grading ID L3962
// Due: 02/13/2019

// File: LibraryBook.cs
// This file creates a simple LibraryBook class capable of tracking
// the book's title, author, publisher, copyright year, call number,
// and checked out status.


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;



public class LibraryBook : LibraryItem
{

    private string _author;     // The book's author
    public const decimal DALIYLATEFEE = 0.25M; 

    // Precondition:  theCopyrightYear >= 0
    //                theTitle, theCallNumber may not be null or empty
    // Postcondition: The library book has been initialized with the specified
    //                values for title, author, publisher, copyright year, and
    //                call number. The book is not checked out.
    public LibraryBook(String theTitle, String theAuthor, String thePublisher, int theCopyrightYear, int theLoanPeriod,
       String theCallNumber): 
        base ( theTitle, thePublisher, theCopyrightYear, theLoanPeriod,
       theCallNumber)
    {
        Author = theAuthor;
    }


    public string Author
    {
        // Precondition:  None
        // Postcondition: The author has been returned 
        get
        {
            return _author;
        }

        // Precondition:  None
        // Postcondition: The author has been set to the specified value
        set
        {
            // Since empty author is OK, just change null to empty string
            _author = (value == null ? string.Empty : value.Trim());
        }
    }
    public override decimal CalcLateFee(int numDaysLate)

    {
        decimal lateFee = 0; 
        if (IsValidDays(numDaysLate))
            lateFee = DALIYLATEFEE * numDaysLate;

        return lateFee;
                
    }




    // Precondition:  None
    // Postcondition: A string is returned representing the libary book's
    //                data on separate lines
    public override string ToString()
    {
        string NL = Environment.NewLine; // NewLine shortcut

        return
            $"LibraryBook{NL}Author: {Author}{NL}{ base.ToString()}";
    }
}

