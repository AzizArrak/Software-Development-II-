﻿// Program 1A
// CIS 200-01
// Grading ID L3962
// Due: 02/13/2019
// Description: LibraryMovie class extended from LibraryMediaItem class


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


    public class LibraryMovie : LibraryMediaItem
    {
        // instance variables
        private string director;
        private MediaType _medium;
        private MPAARatings _rating;
        public const decimal LATEFEEBLURAY = 1.50m; // late fee for BluRay
        public const decimal LATEFEEDVDVHS = 1m; // late fee for both DVD and VHS 
        public const decimal LIMIT = 25m;        // late fee limit
        private decimal total;
        private decimal fee;

        // Parameter constructor
        public LibraryMovie(string theTitle, string thePublisher, int theCopyrightYear, int theLoanPeriod, string theCallNumber, 
            double theDuration, string theDirector, MediaType medium, MPAARatings rating) 
            : base(theTitle, thePublisher, theCopyrightYear, theCallNumber, theLoanPeriod, theDuration)
        {
            // validate via properties
            Director = theDirector;
            Medium = medium;
            Rating = rating;
        }

        // enum for movie MPAA ratings
        public enum MPAARatings { G, PG, PG13, R, NC17, U };

        public string Director
        {
            // Precondition:  None
            // Postcondition: The director has been returned
            get
            {
                return director;
            }

            // Precondition:  None
            // Postcondition: The director has been set to the specified value
            set
            {
                if (!string.IsNullOrWhiteSpace(value)) // IsNullOrWhiteSpace includes tests for null, empty, or all whitespace
                    director = value.Trim();
                else
                    throw new ArgumentOutOfRangeException($"{nameof(Director)}", value,
                        $"{nameof(Director)} Must not be null or empty");
            }
        }

        // not sure how to do this part
        public override MediaType Medium
        {
            get
            {
                return _medium;
            }

            set
            {
                _medium = value;
            }
        }

        public MPAARatings Rating
        {
            // Precondition:  None
            // Postcondition: The rating has been returned
            get
            {
                return _rating;
            }
            // Precondition: none
            // Postcondition: The rating has been set to the specified value
            set
            {
                _rating = value;
            }

        }


        // override CalcLateFee() method to specifie late fee for movie items
        public override decimal CalcLateFee(int daysLate)
        {


            if (Medium == MediaType.VHS || Medium == MediaType.DVD)
            { total = daysLate * LATEFEEDVDVHS; } // total for dvd/vhs
            else
            { total = daysLate * LATEFEEBLURAY; } // total for bluray

            if (total > LIMIT)
                fee = LIMIT;  // if total is over limit
            else
                fee = total;

            return fee;

        }

        // Precondition:  None
        // Postcondition: A string is returned presenting the Library Movie data on
        //                separate lines
        public override string ToString()
        {

            string NL = Environment.NewLine; // newline shortcut

            return $"{base.ToString()}{NL}Director: {Director}{NL}Medium: {Medium}{NL}Rating: {Rating}";
        }
    }

