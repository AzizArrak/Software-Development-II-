﻿// Program 1A
// CIS 200-01
// Grading ID L3962
// Due: 02/13/2019
// Description: LibraryMagazine class extended from LibraryPeriodical class

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;



    public class LibraryMagazine : LibraryPeriodical
    {
        // instance variables
        public const decimal LATEFEE = .25m; // late fee
        private decimal total;
        public const decimal LIMIT = 20m; // fee limit
        private decimal fee;

        // parameter constructor
        public LibraryMagazine(string theTitle, string thePublisher, int theCopyrightYear, int theLoanPeriod,  string theCallNumber,
          int theVolume, int theNumber) : base(theTitle, thePublisher, theCopyrightYear, theLoanPeriod,
                theCallNumber, theVolume, theNumber)
        {


        }

        // override CalcLateFee() method for Magazines
        public override decimal CalcLateFee(int daysLate)
        {
            total = LATEFEE * daysLate;

            if (total > LIMIT) // if over limit
                fee = LIMIT;
            else
                fee = total; // if within limit

            return fee;

        }

        // Precondition:  None
        // Postcondition: A string is returned presenting the Library Magazine data on
        //                separate lines
        public override string ToString()
        {
            return $"{base.ToString()}{Environment.NewLine}";
        }


    }


