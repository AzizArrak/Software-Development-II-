﻿// Program 3
// CIS 200-01
// Due: 4/4/2019
// Grading ID:L3962

// This form creates the Edit Patron dialog box form. It performs validation
// and an int get property for the field associated with the selected index property.



using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace LibraryItems
{
    public partial class EditPatron : Form
    {
        private List<LibraryPatron> patrons; //List of Library Patrons

        //Precondition: List is populated wiht available Library Patrons
        //Postcondition: GUI is ready for display
        public EditPatron(List<LibraryPatron> patronList)
        {
            InitializeComponent();
            patrons = patronList;
        }

        private void EditPatron_Load(object sender, EventArgs e)
        {
            foreach (LibraryPatron patron in patrons) //Populate combo box
            {
                editPatronComboBox.Items.Add(patron.PatronName + ", " + patron.PatronID);
            }
        }

        public int PatronIndex
        {
            //Precondition: None
            //Postcondition: Selected patron idex returned
            get
            {
                return editPatronComboBox.SelectedIndex;
            }
        }

        //Precondition: Focus shifts from selectPatronComboBox 
        //Postcondition: ErrorProvider highlights the field if invalid
        private void editPatronComboBox_Validating(object sender, CancelEventArgs e)
        {
            if (editPatronComboBox.SelectedIndex == -1) //Nothing is selected
            {
                e.Cancel = true;
                errorProvider1.SetError(editPatronComboBox, "Please select a patron");
            }
        }

        //Precondition: Data is OK
        //Postcondition: ErrorProvider cleared
        private void SelectPatronComboBox_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(editPatronComboBox, "");
        }

        //Precondition: OK button pressed
        //Postcondition: If there is an invalid field, it recieves the focus. If not, return OK and form closes.

        private void okBtn_Click(object sender, EventArgs e)
        {
            if (ValidateChildren())
            {
                this.DialogResult = DialogResult.OK;
            }
        }

        //Precondition: Cancel button pressed
        //Postcondtion: Result is cancelled and form is closed
        private void cancelBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
