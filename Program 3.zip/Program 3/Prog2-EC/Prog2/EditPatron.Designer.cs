﻿namespace LibraryItems
{
    partial class EditPatron
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.editBookLabel = new System.Windows.Forms.Label();
            this.editPatronlabel = new System.Windows.Forms.Label();
            this.editPatronComboBox = new System.Windows.Forms.ComboBox();
            this.okBtn = new System.Windows.Forms.Button();
            this.cancelBtn = new System.Windows.Forms.Button();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // editBookLabel
            // 
            this.editBookLabel.AutoSize = true;
            this.editBookLabel.Location = new System.Drawing.Point(180, 66);
            this.editBookLabel.Name = "editBookLabel";
            this.editBookLabel.Size = new System.Drawing.Size(0, 25);
            this.editBookLabel.TabIndex = 0;
            // 
            // editPatronlabel
            // 
            this.editPatronlabel.AutoSize = true;
            this.editPatronlabel.Location = new System.Drawing.Point(135, 66);
            this.editPatronlabel.Name = "editPatronlabel";
            this.editPatronlabel.Size = new System.Drawing.Size(273, 25);
            this.editPatronlabel.TabIndex = 1;
            this.editPatronlabel.Text = "Please select patron to edit";
            // 
            // editPatronComboBox
            // 
            this.editPatronComboBox.FormattingEnabled = true;
            this.editPatronComboBox.Location = new System.Drawing.Point(94, 124);
            this.editPatronComboBox.Name = "editPatronComboBox";
            this.editPatronComboBox.Size = new System.Drawing.Size(331, 33);
            this.editPatronComboBox.TabIndex = 2;
            this.editPatronComboBox.Validating += new System.ComponentModel.CancelEventHandler(this.editPatronComboBox_Validating);
            this.editPatronComboBox.Validated += new System.EventHandler(this.SelectPatronComboBox_Validated);
            // 
            // okBtn
            // 
            this.okBtn.Location = new System.Drawing.Point(94, 237);
            this.okBtn.Name = "okBtn";
            this.okBtn.Size = new System.Drawing.Size(171, 47);
            this.okBtn.TabIndex = 3;
            this.okBtn.Text = "Ok";
            this.okBtn.UseVisualStyleBackColor = true;
            this.okBtn.Click += new System.EventHandler(this.okBtn_Click);
            // 
            // cancelBtn
            // 
            this.cancelBtn.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.cancelBtn.Location = new System.Drawing.Point(297, 237);
            this.cancelBtn.Name = "cancelBtn";
            this.cancelBtn.Size = new System.Drawing.Size(171, 47);
            this.cancelBtn.TabIndex = 4;
            this.cancelBtn.Text = "Cancel";
            this.cancelBtn.UseVisualStyleBackColor = true;
            this.cancelBtn.Click += new System.EventHandler(this.cancelBtn_Click);
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // EditPatron
            // 
            this.AcceptButton = this.okBtn;
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.cancelBtn;
            this.ClientSize = new System.Drawing.Size(596, 395);
            this.Controls.Add(this.cancelBtn);
            this.Controls.Add(this.okBtn);
            this.Controls.Add(this.editPatronComboBox);
            this.Controls.Add(this.editPatronlabel);
            this.Controls.Add(this.editBookLabel);
            this.Name = "EditPatron";
            this.Text = "EditPatron";
            this.Load += new System.EventHandler(this.EditPatron_Load);
            this.Validating += new System.ComponentModel.CancelEventHandler(this.editPatronComboBox_Validating);
            this.Validated += new System.EventHandler(this.SelectPatronComboBox_Validated);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label editBookLabel;
        private System.Windows.Forms.Label editPatronlabel;
        private System.Windows.Forms.ComboBox editPatronComboBox;
        private System.Windows.Forms.Button okBtn;
        private System.Windows.Forms.Button cancelBtn;
        private System.Windows.Forms.ErrorProvider errorProvider1;
    }
}