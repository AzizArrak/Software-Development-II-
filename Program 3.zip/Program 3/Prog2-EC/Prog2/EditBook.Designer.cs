﻿namespace LibraryItems
{
    partial class EditBook
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.editBooklabel = new System.Windows.Forms.Label();
            this.editBookcomboBox = new System.Windows.Forms.ComboBox();
            this.okBtn = new System.Windows.Forms.Button();
            this.cancelBtn = new System.Windows.Forms.Button();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // editBooklabel
            // 
            this.editBooklabel.AutoSize = true;
            this.editBooklabel.Location = new System.Drawing.Point(180, 87);
            this.editBooklabel.Name = "editBooklabel";
            this.editBooklabel.Size = new System.Drawing.Size(259, 25);
            this.editBooklabel.TabIndex = 0;
            this.editBooklabel.Text = "Please select book to edit";
            // 
            // editBookcomboBox
            // 
            this.editBookcomboBox.FormattingEnabled = true;
            this.editBookcomboBox.Location = new System.Drawing.Point(132, 141);
            this.editBookcomboBox.Name = "editBookcomboBox";
            this.editBookcomboBox.Size = new System.Drawing.Size(377, 33);
            this.editBookcomboBox.TabIndex = 1;
            this.editBookcomboBox.Validating += new System.ComponentModel.CancelEventHandler(this.editBookcomboBox_Validating);
            this.editBookcomboBox.Validated += new System.EventHandler(this.selectBookComboBox_Validated);
            // 
            // okBtn
            // 
            this.okBtn.Location = new System.Drawing.Point(141, 229);
            this.okBtn.Name = "okBtn";
            this.okBtn.Size = new System.Drawing.Size(179, 54);
            this.okBtn.TabIndex = 2;
            this.okBtn.Text = "Ok";
            this.okBtn.UseVisualStyleBackColor = true;
            this.okBtn.Click += new System.EventHandler(this.okBtn_Click);
            // 
            // cancelBtn
            // 
            this.cancelBtn.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.cancelBtn.Location = new System.Drawing.Point(365, 229);
            this.cancelBtn.Name = "cancelBtn";
            this.cancelBtn.Size = new System.Drawing.Size(179, 54);
            this.cancelBtn.TabIndex = 3;
            this.cancelBtn.Text = "Cancel";
            this.cancelBtn.UseVisualStyleBackColor = true;
            this.cancelBtn.Click += new System.EventHandler(this.cancelBtn_Click);
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // EditBook
            // 
            this.AcceptButton = this.okBtn;
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.cancelBtn;
            this.ClientSize = new System.Drawing.Size(639, 383);
            this.Controls.Add(this.cancelBtn);
            this.Controls.Add(this.okBtn);
            this.Controls.Add(this.editBookcomboBox);
            this.Controls.Add(this.editBooklabel);
            this.Name = "EditBook";
            this.Text = "EditBook";
            this.Load += new System.EventHandler(this.EditBook_Load);
            this.Validating += new System.ComponentModel.CancelEventHandler(this.editBookcomboBox_Validating);
            this.Validated += new System.EventHandler(this.selectBookComboBox_Validated);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label editBooklabel;
        private System.Windows.Forms.ComboBox editBookcomboBox;
        private System.Windows.Forms.Button okBtn;
        private System.Windows.Forms.Button cancelBtn;
        private System.Windows.Forms.ErrorProvider errorProvider1;
    }
}