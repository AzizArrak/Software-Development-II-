﻿namespace LibraryItems
{
    partial class InputPatronForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.patNameLbl = new System.Windows.Forms.Label();
            this.patIdLbl = new System.Windows.Forms.Label();
            this.patronNameTxtBox = new System.Windows.Forms.TextBox();
            this.patronIdTxtBox = new System.Windows.Forms.TextBox();
            this.addPatBtn = new System.Windows.Forms.Button();
            this.patInputError = new System.Windows.Forms.ErrorProvider(this.components);
            this.cancelBtn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.patInputError)).BeginInit();
            this.SuspendLayout();
            // 
            // patNameLbl
            // 
            this.patNameLbl.AutoSize = true;
            this.patNameLbl.Font = new System.Drawing.Font("Century Gothic", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.patNameLbl.Location = new System.Drawing.Point(45, 46);
            this.patNameLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.patNameLbl.Name = "patNameLbl";
            this.patNameLbl.Size = new System.Drawing.Size(152, 24);
            this.patNameLbl.TabIndex = 0;
            this.patNameLbl.Text = "Patron Name:";
            // 
            // patIdLbl
            // 
            this.patIdLbl.AutoSize = true;
            this.patIdLbl.Font = new System.Drawing.Font("Century Gothic", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.patIdLbl.Location = new System.Drawing.Point(81, 112);
            this.patIdLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.patIdLbl.Name = "patIdLbl";
            this.patIdLbl.Size = new System.Drawing.Size(108, 24);
            this.patIdLbl.TabIndex = 1;
            this.patIdLbl.Text = "Patron ID:";
            // 
            // patNameTxtBox
            // 
            this.patronNameTxtBox.Location = new System.Drawing.Point(201, 43);
            this.patronNameTxtBox.Margin = new System.Windows.Forms.Padding(2);
            this.patronNameTxtBox.Name = "patNameTxtBox";
            this.patronNameTxtBox.Size = new System.Drawing.Size(174, 31);
            this.patronNameTxtBox.TabIndex = 2;
            this.patronNameTxtBox.Validating += new System.ComponentModel.CancelEventHandler(this.patNameTxtBox_Validating);
            this.patronNameTxtBox.Validated += new System.EventHandler(this.patNameTxtBox_Validated);
            // 
            // patIdTxtBox
            // 
            this.patronIdTxtBox.Location = new System.Drawing.Point(201, 105);
            this.patronIdTxtBox.Margin = new System.Windows.Forms.Padding(2);
            this.patronIdTxtBox.Name = "patIdTxtBox";
            this.patronIdTxtBox.Size = new System.Drawing.Size(174, 31);
            this.patronIdTxtBox.TabIndex = 3;
            this.patronIdTxtBox.Validating += new System.ComponentModel.CancelEventHandler(this.patIdTxtBox_Validating);
            this.patronIdTxtBox.Validated += new System.EventHandler(this.patIdTxtBox_Validated);
            // 
            // addPatBtn
            // 
            this.addPatBtn.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.addPatBtn.Font = new System.Drawing.Font("Century Gothic", 7.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addPatBtn.Location = new System.Drawing.Point(64, 214);
            this.addPatBtn.Margin = new System.Windows.Forms.Padding(2);
            this.addPatBtn.Name = "addPatBtn";
            this.addPatBtn.Size = new System.Drawing.Size(170, 47);
            this.addPatBtn.TabIndex = 4;
            this.addPatBtn.Text = "Add Patron";
            this.addPatBtn.UseVisualStyleBackColor = true;
            this.addPatBtn.Click += new System.EventHandler(this.addPatBtn_Click);
            // 
            // patInputError
            // 
            this.patInputError.ContainerControl = this;
            // 
            // cancelBtn
            // 
            this.cancelBtn.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.cancelBtn.Font = new System.Drawing.Font("Century Gothic", 7.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cancelBtn.Location = new System.Drawing.Point(287, 214);
            this.cancelBtn.Name = "cancelBtn";
            this.cancelBtn.Size = new System.Drawing.Size(160, 49);
            this.cancelBtn.TabIndex = 5;
            this.cancelBtn.Text = "Cancel ";
            this.cancelBtn.UseVisualStyleBackColor = true;
            this.cancelBtn.Click += new System.EventHandler(this.button1_Click);
            this.cancelBtn.MouseDown += new System.Windows.Forms.MouseEventHandler(this.cancelBtn_MouseDown);
            // 
            // InputPatronForm
            // 
            this.AcceptButton = this.addPatBtn;
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.cancelBtn;
            this.ClientSize = new System.Drawing.Size(494, 354);
            this.Controls.Add(this.cancelBtn);
            this.Controls.Add(this.addPatBtn);
            this.Controls.Add(this.patronIdTxtBox);
            this.Controls.Add(this.patronNameTxtBox);
            this.Controls.Add(this.patIdLbl);
            this.Controls.Add(this.patNameLbl);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "InputPatronForm";
            this.Text = "InputPatronForm";
            ((System.ComponentModel.ISupportInitialize)(this.patInputError)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label patNameLbl;
        private System.Windows.Forms.Label patIdLbl;
        private System.Windows.Forms.TextBox patronNameTxtBox;
        private System.Windows.Forms.TextBox patronIdTxtBox;
        private System.Windows.Forms.Button addPatBtn;
        private System.Windows.Forms.ErrorProvider patInputError;
        private System.Windows.Forms.Button cancelBtn;
    }
}