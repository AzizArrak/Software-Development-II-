﻿// Program 2
// CIS 200-01
// Due:03/10/2019
// Grading ID: L3962

// Description: Input Patron Form, captures input data to be stored in Library

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryItems
{
    public partial class InputPatronForm : Form
    {
        public InputPatronForm()
        {
            InitializeComponent();
        }

        //Precondition: none
        //Postcondition: a patron name is returned
        internal string patronName
        {
            get
            {
                return patronNameTxtBox.Text;
            }

            set
            {
                patronNameTxtBox.Text = value;
            }
        }

        //Precondition: none
        //Postcondition: a patron ID is returned
        internal string patronId
        {
            get
            {
                return patronIdTxtBox.Text;
            }

            set
            {
                patronIdTxtBox.Text = value;
            }
        }

        //Precondition: none
        //Postcondition: set error if invalid input
        private void patNameTxtBox_Validating(object sender, CancelEventArgs e)
        {
            if (patronNameTxtBox.Text == string.Empty)
            { 
                e.Cancel = true;        
                patInputError.SetError(patronNameTxtBox, "Please Enter Valid Name!");

            }
        }

        //Precondition: none
        //Postcondition: set error 
        private void patNameTxtBox_Validated(object sender, EventArgs e)
        {
            patInputError.SetError(patronNameTxtBox, "");
        }


        //Precondition: none
        //Postcondition: set error if invalid input
        private void patIdTxtBox_Validating(object sender, CancelEventArgs e)
        {
            if (patronIdTxtBox.Text == string.Empty)
            { 
                e.Cancel = true;        
                patInputError.SetError(patronIdTxtBox, " Please Enter Valid ID!");

            }
        }

        //Precondition: none
        //Postcondition: set error 
        private void patIdTxtBox_Validated(object sender, EventArgs e)
        {
            patInputError.SetError(patronIdTxtBox, "");
        }

        //Precondition: validation
        //Postcondition: ok to add patron
        private void addPatBtn_Click(object sender, EventArgs e)
        {
            if (this.ValidateChildren())
            {
                this.DialogResult = DialogResult.OK;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
         
        }

        private void cancelBtn_MouseDown(object sender, MouseEventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }
    }
}
