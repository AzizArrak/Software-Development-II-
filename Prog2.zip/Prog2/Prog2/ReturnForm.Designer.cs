﻿namespace LibraryItems
{
    partial class ReturnForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.selectReturnItemLabel = new System.Windows.Forms.Label();
            this.returnItemComboBx = new System.Windows.Forms.ComboBox();
            this.returnButton = new System.Windows.Forms.Button();
            this.returnError = new System.Windows.Forms.ErrorProvider(this.components);
            this.cancelBtn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.returnError)).BeginInit();
            this.SuspendLayout();
            // 
            // selectReturnItemLabel
            // 
            this.selectReturnItemLabel.AutoSize = true;
            this.selectReturnItemLabel.Font = new System.Drawing.Font("Century Gothic", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.selectReturnItemLabel.Location = new System.Drawing.Point(78, 74);
            this.selectReturnItemLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.selectReturnItemLabel.Name = "selectReturnItemLabel";
            this.selectReturnItemLabel.Size = new System.Drawing.Size(132, 24);
            this.selectReturnItemLabel.TabIndex = 0;
            this.selectReturnItemLabel.Text = "Select Item:";
            // 
            // returnItemComboBx
            // 
            this.returnItemComboBx.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.returnItemComboBx.FormattingEnabled = true;
            this.returnItemComboBx.Location = new System.Drawing.Point(82, 102);
            this.returnItemComboBx.Margin = new System.Windows.Forms.Padding(2);
            this.returnItemComboBx.Name = "returnItemComboBx";
            this.returnItemComboBx.Size = new System.Drawing.Size(377, 33);
            this.returnItemComboBx.TabIndex = 2;
            this.returnItemComboBx.Validating += new System.ComponentModel.CancelEventHandler(this.returnItemComboBx_Validating);
            this.returnItemComboBx.Validated += new System.EventHandler(this.returnItemComboBx_Validated);
            // 
            // returnButton
            // 
            this.returnButton.Font = new System.Drawing.Font("Century Gothic", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.returnButton.Location = new System.Drawing.Point(82, 231);
            this.returnButton.Margin = new System.Windows.Forms.Padding(2);
            this.returnButton.Name = "returnButton";
            this.returnButton.Size = new System.Drawing.Size(194, 56);
            this.returnButton.TabIndex = 4;
            this.returnButton.Text = "Return";
            this.returnButton.UseVisualStyleBackColor = true;
            this.returnButton.Click += new System.EventHandler(this.returnButton_Click);
            // 
            // returnError
            // 
            this.returnError.ContainerControl = this;
            // 
            // cancelBtn
            // 
            this.cancelBtn.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.cancelBtn.Font = new System.Drawing.Font("Century Gothic", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cancelBtn.Location = new System.Drawing.Point(314, 232);
            this.cancelBtn.Margin = new System.Windows.Forms.Padding(2);
            this.cancelBtn.Name = "cancelBtn";
            this.cancelBtn.Size = new System.Drawing.Size(194, 55);
            this.cancelBtn.TabIndex = 5;
            this.cancelBtn.Text = "Cancel";
            this.cancelBtn.UseVisualStyleBackColor = true;
            this.cancelBtn.Click += new System.EventHandler(this.cancelBtn_Click);
            this.cancelBtn.MouseDown += new System.Windows.Forms.MouseEventHandler(this.cancelBtn_MouseDown);
            // 
            // ReturnForm
            // 
            this.AcceptButton = this.returnButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.cancelBtn;
            this.ClientSize = new System.Drawing.Size(587, 336);
            this.Controls.Add(this.cancelBtn);
            this.Controls.Add(this.returnButton);
            this.Controls.Add(this.returnItemComboBx);
            this.Controls.Add(this.selectReturnItemLabel);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "ReturnForm";
            this.Text = "ReturnForm";
            this.Load += new System.EventHandler(this.ReturnForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.returnError)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label selectReturnItemLabel;
        private System.Windows.Forms.ComboBox returnItemComboBx;
        private System.Windows.Forms.Button returnButton;
        private System.Windows.Forms.ErrorProvider returnError;
        private System.Windows.Forms.Button cancelBtn;
    }
}