﻿namespace LibraryItems
{
    partial class CheckOutForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.selectItemLbl = new System.Windows.Forms.Label();
            this.selectPatronLbl = new System.Windows.Forms.Label();
            this.selectItemComboBx = new System.Windows.Forms.ComboBox();
            this.selectPatronComboBx = new System.Windows.Forms.ComboBox();
            this.checkOutBtn = new System.Windows.Forms.Button();
            this.checkoutError = new System.Windows.Forms.ErrorProvider(this.components);
            this.cancelBtn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.checkoutError)).BeginInit();
            this.SuspendLayout();
            // 
            // selectItemLbl
            // 
            this.selectItemLbl.AutoSize = true;
            this.selectItemLbl.Font = new System.Drawing.Font("Century Gothic", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.selectItemLbl.Location = new System.Drawing.Point(64, 48);
            this.selectItemLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.selectItemLbl.Name = "selectItemLbl";
            this.selectItemLbl.Size = new System.Drawing.Size(132, 24);
            this.selectItemLbl.TabIndex = 0;
            this.selectItemLbl.Text = "Select Item:";
            // 
            // selectPatronLbl
            // 
            this.selectPatronLbl.AutoSize = true;
            this.selectPatronLbl.Font = new System.Drawing.Font("Century Gothic", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.selectPatronLbl.Location = new System.Drawing.Point(64, 166);
            this.selectPatronLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.selectPatronLbl.Name = "selectPatronLbl";
            this.selectPatronLbl.Size = new System.Drawing.Size(151, 24);
            this.selectPatronLbl.TabIndex = 1;
            this.selectPatronLbl.Text = "Select Patron:";
            // 
            // selectItemComboBx
            // 
            this.selectItemComboBx.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.selectItemComboBx.FormattingEnabled = true;
            this.selectItemComboBx.Location = new System.Drawing.Point(69, 88);
            this.selectItemComboBx.Margin = new System.Windows.Forms.Padding(2);
            this.selectItemComboBx.Name = "selectItemComboBx";
            this.selectItemComboBx.Size = new System.Drawing.Size(349, 33);
            this.selectItemComboBx.TabIndex = 2;
            this.selectItemComboBx.SelectedIndexChanged += new System.EventHandler(this.selectItemComboBx_SelectedIndexChanged);
            this.selectItemComboBx.Validating += new System.ComponentModel.CancelEventHandler(this.selectItemComboBx_Validating);
            this.selectItemComboBx.Validated += new System.EventHandler(this.selectItemComboBx_Validated);
            // 
            // selectPatronComboBx
            // 
            this.selectPatronComboBx.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.selectPatronComboBx.FormattingEnabled = true;
            this.selectPatronComboBx.Location = new System.Drawing.Point(69, 205);
            this.selectPatronComboBx.Margin = new System.Windows.Forms.Padding(2);
            this.selectPatronComboBx.Name = "selectPatronComboBx";
            this.selectPatronComboBx.Size = new System.Drawing.Size(290, 33);
            this.selectPatronComboBx.TabIndex = 3;
            this.selectPatronComboBx.Validating += new System.ComponentModel.CancelEventHandler(this.selectPatronComboBx_Validating);
            this.selectPatronComboBx.Validated += new System.EventHandler(this.selectPatronComboBx_Validated);
            // 
            // checkOutBtn
            // 
            this.checkOutBtn.Font = new System.Drawing.Font("Century Gothic", 7.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkOutBtn.Location = new System.Drawing.Point(59, 290);
            this.checkOutBtn.Margin = new System.Windows.Forms.Padding(2);
            this.checkOutBtn.Name = "checkOutBtn";
            this.checkOutBtn.Size = new System.Drawing.Size(177, 47);
            this.checkOutBtn.TabIndex = 4;
            this.checkOutBtn.Text = "CheckOut";
            this.checkOutBtn.UseVisualStyleBackColor = true;
            this.checkOutBtn.Click += new System.EventHandler(this.checkOutBtn_Click);
            // 
            // checkoutError
            // 
            this.checkoutError.ContainerControl = this;
            // 
            // cancelBtn
            // 
            this.cancelBtn.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.cancelBtn.Font = new System.Drawing.Font("Century Gothic", 7.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cancelBtn.Location = new System.Drawing.Point(275, 290);
            this.cancelBtn.Margin = new System.Windows.Forms.Padding(2);
            this.cancelBtn.Name = "cancelBtn";
            this.cancelBtn.Size = new System.Drawing.Size(186, 47);
            this.cancelBtn.TabIndex = 5;
            this.cancelBtn.Text = "Cancel";
            this.cancelBtn.UseVisualStyleBackColor = true;
            this.cancelBtn.Click += new System.EventHandler(this.cancelBtn_Click);
            this.cancelBtn.MouseDown += new System.Windows.Forms.MouseEventHandler(this.cancelBtn_MouseDown);
            // 
            // CheckOutForm
            // 
            this.AcceptButton = this.checkOutBtn;
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.cancelBtn;
            this.ClientSize = new System.Drawing.Size(496, 408);
            this.Controls.Add(this.cancelBtn);
            this.Controls.Add(this.checkOutBtn);
            this.Controls.Add(this.selectPatronComboBx);
            this.Controls.Add(this.selectItemComboBx);
            this.Controls.Add(this.selectPatronLbl);
            this.Controls.Add(this.selectItemLbl);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "CheckOutForm";
            this.Text = "CheckOutForm";
            this.Load += new System.EventHandler(this.CheckOutForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.checkoutError)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label selectItemLbl;
        private System.Windows.Forms.Label selectPatronLbl;
        private System.Windows.Forms.ComboBox selectItemComboBx;
        private System.Windows.Forms.ComboBox selectPatronComboBx;
        private System.Windows.Forms.Button checkOutBtn;
        private System.Windows.Forms.ErrorProvider checkoutError;
        private System.Windows.Forms.Button cancelBtn;
    }
}